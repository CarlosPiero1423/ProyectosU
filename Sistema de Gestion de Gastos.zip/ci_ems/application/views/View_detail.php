      <!-- partial -->
      <div class="main-panel">
          <div class="content-wrapper">
              <div class="col-12 grid-margin">
                  <div class="card">
                      <div class="card-body">
                          <h4 class="card-title">Horizontal Two column</h4>
                          <form class="form-sample">
                              <p class="card-description">
                                  Personal info
                              </p>
                              <div class="container">
                                  <div class="row">
                                      <div class="col-md-4">
                                          <div class="well well-sm">
                                              <div class="media">
                                                  <a class="thumbnail pull-left" href="#">
                                                      <img class="media-object" src="#">
                                                  </a>
                                                  <div class="media-body">
                                                      <h4 class="media-heading">First Last Name</h4>

                                                      <p>
                                                          <a href="#" class="btn btn-xs btn-default"><span
                                                                  class="glyphicon glyphicon-comment"></span>
                                                              Message</a>
                                                          <a href="#" class="btn btn-xs btn-default"><span
                                                                  class="glyphicon glyphicon-heart"></span> Favorite</a>
                                                          <a href="#" class="btn btn-xs btn-default"><span
                                                                  class="glyphicon glyphicon-ban-circle"></span>
                                                              Unfollow</a>
                                                      </p>
                                                  </div>
                                              </div>
                                          </div>
                                      </div>
                                  </div>
                              </div>
                              <p class="card-description">
                                  Address
                              </p>



                          </form>
                      </div>
                  </div>
              </div>

              <script>
              $(function() {
                  $("#example").simplePagination({
                      previousButtonClass: "btn btn-gradient-primary btn-sm",
                      nextButtonClass: "btn btn-gradient-primary btn-sm"
                  });


              });
              </script>






          </div>
          <!-- content-wrapper ends -->